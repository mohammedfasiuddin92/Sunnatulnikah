-- Run in Supabase SQL Editor. Review before production use.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade
);
create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  kind text not null check (kind in ('Bride','Groom')),
  display_name text not null check (char_length(display_name) between 1 and 60),
  age integer not null check (age between 18 and 100),
  city text not null check (char_length(city) between 1 and 80),
  marital_status text not null check (marital_status in ('Never married','Divorced','Widowed')),
  about text not null check (char_length(about) between 1 and 700),
  preferences text not null default '' check (char_length(preferences) <= 700),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists profiles_approved_idx on public.profiles (approved, created_at desc);
alter table public.admin_users enable row level security;
alter table public.profiles enable row level security;

-- Members may check only their own admin status.
drop policy if exists "Read own admin status" on public.admin_users;
create policy "Read own admin status" on public.admin_users for select to authenticated using (user_id = (select auth.uid()));

-- Security-definer function avoids recursive RLS checks in admin policies.
create or replace function public.is_site_admin() returns boolean
language sql stable security definer set search_path = ''
as $$ select exists(select 1 from public.admin_users where user_id = (select auth.uid())); $$;
revoke all on function public.is_site_admin() from public;
grant execute on function public.is_site_admin() to authenticated;

-- Allow viewing own profile, approved profiles, or all for admins.
drop policy if exists "Read eligible profiles" on public.profiles;
create policy "Read eligible profiles" on public.profiles for select to authenticated
using (user_id = (select auth.uid()) or approved = true or public.is_site_admin());

drop policy if exists "Insert own profile" on public.profiles;
create policy "Insert own profile" on public.profiles for insert to authenticated
with check (user_id = (select auth.uid()) and approved = false);

drop policy if exists "Update own or admin profiles" on public.profiles;
create policy "Update own or admin profiles" on public.profiles for update to authenticated
using (user_id = (select auth.uid()) or public.is_site_admin())
with check (user_id = (select auth.uid()) or public.is_site_admin());

-- Critical: prevent ordinary members from self-approving and require re-review after edits.
create or replace function public.guard_profile_changes() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    new.approved := false;
    return new;
  end if;
  if not public.is_site_admin() then
    if new.user_id is distinct from old.user_id then
      raise exception 'Cannot change profile owner';
    end if;
    new.approved := false;
    new.created_at := old.created_at;
  end if;
  return new;
end; $$;
drop trigger if exists profile_change_guard on public.profiles;
create trigger profile_change_guard before insert or update on public.profiles
for each row execute function public.guard_profile_changes();

-- After signing up and confirming your email, get your user UUID in
-- Supabase > Authentication > Users, then run this SQL in the SQL editor:
-- insert into public.admin_users(user_id) values ('PASTE-YOUR-USER-UUID-HERE');
-- Do NOT add a public insert policy for admin_users.
