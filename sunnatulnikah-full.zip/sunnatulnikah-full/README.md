# SunnatulNikah — Free matrimonial website starter

## What works
- Responsive homepage, how it works, contact and privacy sections
- Supabase email/password sign-up, sign-in, sign-out and password reset email
- Member profile submission, editable profile, 18+ validation
- Member-only approved profile directory
- Admin-only profile review and approval
- Row-level security and server-side prevention of self-approval

## What is NOT included
- Automatic matchmaking algorithm, private messaging, photo uploads, identity verification, payments, email delivery from your own domain, and complete privacy-law compliance
- A purchased `sunnatulnikah.com` domain
- Unlimited free resources (Supabase and GitHub free plans have limits)

## Setup
1. Create a free Supabase project at https://supabase.com/dashboard
2. In Supabase > SQL Editor, run the contents of `database.sql`.
3. In Supabase > Project Settings > API / Connect, copy the project URL and **publishable/anon** key. Never use the secret/service_role key in browser code.
4. Open `index.html` in a text editor and replace `YOUR_SUPABASE_URL`, `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY`, and `YOUR_BUSINESS_EMAIL`.
5. In Supabase > Authentication > URL Configuration, set Site URL to your deployed GitHub Pages URL and add it under Redirect URLs, e.g. `https://YOUR-USERNAME.github.io/sunnatulnikah/`. Set this before testing confirmation emails.
6. In Supabase > Authentication > Providers > Email, enable email/password authentication and choose confirmation settings. For public launch, configure reliable production SMTP: the built-in free email sender has limits and is not suitable for arbitrary public email addresses.
7. Create a public GitHub repository called `sunnatulnikah`, upload `index.html` to its root, and use Settings > Pages > Deploy from a branch > main / root. GitHub Pages is public hosting, not a private server.
8. Open the published site, create your own account, confirm email, and find your account UUID in Supabase > Authentication > Users.
9. In SQL Editor, run: `insert into public.admin_users(user_id) values ('YOUR-UUID');` (replace placeholder). Sign out and sign back in to see Admin.
10. Test with a second account: submit profile, confirm it stays hidden, approve as admin, confirm it appears for signed-in members, edit it as the member, confirm it returns to pending.

## Important safety and launch checks
- This site processes potentially sensitive matrimonial data. Keep profile fields minimal and never include phone numbers, home addresses, identity documents, or personal contact information in public-facing fields.
- Admin review does not verify identity, age, or marital status. Develop safety and moderation procedures.
- Finalize a real privacy policy, data retention/deletion workflow, consent, jurisdiction-specific legal compliance, and a safe introductions process before inviting real users.
- Member profiles are visible to *all authenticated users* after approval, not to the anonymous internet. Do not claim end-to-end privacy.
- The Reset password button sends a recovery email; a custom set-new-password page is not implemented in this starter. Complete this before production launch.
- For user account deletion, an administrator must currently handle deletion in Supabase Auth; deletion cascades to profile records.
- Supabase free projects can pause after inactivity, and GitHub Pages is static hosting.
